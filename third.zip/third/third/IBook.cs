﻿namespace third
{
    public interface IBook
    {
        public List<Book> GetBook();
        public void Add(Book addedbook);
        public List<User> GetUser();

    }
}
