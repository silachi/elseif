﻿namespace third
{
    public class Book
    {
        public int id { get; set; }
        public string name { get; set; }
        public int price { get; set; }
    }
}
