﻿namespace third
{
    public class User
    {
        public int? userID { get; set; }
       public  string userName { get; set; }

       public List<int> ? ids { get; set; }
        public List<Book> ? userBookList { get; set; }

    }
   
}
