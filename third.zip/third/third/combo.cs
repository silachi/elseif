﻿namespace third
{
    public class combo
    {
        public List<Book> oho;
        public List<User> aha;
    }
}
