﻿namespace third
{
    public interface Iuserdata
    {
        public List<User> GetUser();


    }
}
