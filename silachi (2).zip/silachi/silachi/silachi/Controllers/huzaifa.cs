﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace silachi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class huzaifaController : ControllerBase
    {
        private IBook logger;
        public myController(IBook logger)
        {
            this.logger = logger;
        }



        public IActionResult getbookdetail(int id)
        {
            List<Book> books = logger.GetBook();
            Book bookDetail = (from book in books where book.id == id select book).FirstOrDefault();
            if (bookDetail == null)
            {
                return NotFound("Book is issued by a user");
            }
            else
            {
                return Ok(bookDetail);
            }

        }




    }
}
