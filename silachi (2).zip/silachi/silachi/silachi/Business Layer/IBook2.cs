﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using silachi.
namespace silachi.Business_Layer
{
    interface IBook2
    {
        public List<Book> Get_book();
    }
}
