﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using silachi.Models;

using System.Data;
using System.Data.SqlClient;

using Microsoft.Extensions.Configuration;

namespace silachi.Data_Acces_Layer
{
    public class sqlDataHelper : IsqlDataHelper
    {
        string connectionString = "";

        public sqlDataHelper(IConfiguration config)
        {
            var c = config;
            connectionString = config.GetConnectionString("projectDB");
        }

        public Book GetBook()
        {
            Book mybook = new Book();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("spGetBookDetails", con);

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {


                    mybook.id = Convert.ToInt32(sdr["id_book"]);
                    mybook.name = sdr["name_book"].ToString();
                    mybook.price = Convert.ToInt32(sdr["price_book"]);


                }
                con.Close();
            }
            return mybook;


        }
    }
}
