﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using silachi.Models;

namespace silachi.Data_Acces_Layer
{
    interface IsqlDataHelper
    {
        public Book GetBook();
        

    }
}
