﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using silachi.Models;

using System.Data;
using System.Data.SqlClient;

using Microsoft.Extensions.Configuration;

namespace silachi.Data_Acces_Layer
{
    public class sqlDataHelper : IsqlDataHelper
    {
        string connectionString = "";

        public sqlDataHelper(IConfiguration config)
        {
            var c = config;
            connectionString = config.GetConnectionString("projectDB");
        }
       
        public Book GetBOOK()
        {
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("spGetBookDetails", con);

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
            }



        }
}
