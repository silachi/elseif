﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using silachi.Business_Layer;
using silachi.Models;
using System.Collections.Generic;

namespace silachi.Controllers
{
    [Route("Library")]
    [ApiController]
    public class LibraryController : ControllerBase
    {

        ILibrary _Library;
        public LibraryController(ILibrary _Library)
        {
            this._Library = _Library;
        }
        [HttpGet("getbookdetail/{name}")]
        public IActionResult getbookdetail(string name)
        {
            Book mybook = _Library.Get_book(name);
            //Book bookDetail =(from book in books where book.id == id select book).FirstOrDefault();
            if (mybook.name == null)
            {

                return NotFound("Book is issue? by a user");
            }
            else
            {
                return Ok(mybook);
            }




        }

        [HttpPost("addbook")]

        public void bookaddition([FromBody] Book newbook)
        {

            _Library.AddBook(newbook);

            

          
        }
    }
}
