﻿using silachi.Models;
namespace silachi.DATA_Acces_Layer
{
    public interface ISQADataHelper
    {
     
            public Book GetBook(string name);
        public void AddBook(Book book);



    }
}
