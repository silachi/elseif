﻿using Microsoft.Extensions.Configuration;
using silachi.Models;
using System.Data.SqlClient;
using System.Data;
using System;

namespace silachi.DATA_Acces_Layer
{
    public class SQADataHelper:ISQADataHelper
    {
        string connectionString = "";
        public SQADataHelper(IConfiguration config)
        {
            var c = config;
            connectionString = config.GetConnectionString("projectDB");
        }
        public Book GetBook(string name)
        {
            Book mybook = new Book();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_GetBookDetails", con);
               
                cmd.Parameters.Add("@name_book", SqlDbType.VarChar).Value = name;

                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                SqlDataReader sdr = cmd.ExecuteReader();
                while (sdr.Read())
                {


                    mybook.id = Convert.ToInt32(sdr["id_book"]);
                    mybook.name = sdr["name_book"].ToString();
                    mybook.price = Convert.ToInt32(sdr["price_book"]);


                }
                con.Close();
            }
            return mybook;


        }
        // ADD book in the library books

        public void AddBook(Book book)
        {
            //Book mybook = new Book();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_AddBook", con);

                cmd.Parameters.Add("@name_book", SqlDbType.VarChar).Value = book.name;
                cmd.Parameters.Add("@price_book", SqlDbType.Int).Value = book.price;


                cmd.CommandType = CommandType.StoredProcedure;
                con.Open();
                cmd.ExecuteNonQuery();
                con.Close();
               
            }
           


        }
    }
}
