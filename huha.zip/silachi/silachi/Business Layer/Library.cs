﻿
using silachi.DATA_Acces_Layer;
using silachi.Models;


namespace silachi.Business_Layer
{
    public class Library:ILibrary
    {
        ISQADataHelper _SQADataHelper;

        public Library(ISQADataHelper _SQADataHelper)
        {
           this._SQADataHelper = _SQADataHelper;
        }
        public Book Get_book(string name)
        {
            return _SQADataHelper.GetBook(name);
        }
        public void AddBook(Book book)
        {
            _SQADataHelper.AddBook(book);
            
        }
    }
}
