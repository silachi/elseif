﻿using silachi.Models;
using System.Collections.Generic;

namespace silachi.Business_Layer
{
    public interface ILibrary
    {
        public Book Get_book(string name);
        public void AddBook(Book book);
    }
}
